use flink_realtime;



-- 存储过程 使用call 调用
DELIMITER $$
CREATE PROCEDURE task_sup_user_info()
BEGIN
    -- 1. 创建表（如果不存在）
    CREATE TABLE IF NOT EXISTS user_info_sup_msg (
        id           INT PRIMARY KEY AUTO_INCREMENT,
        uid          INT,
        gender       VARCHAR(2),
        height       VARCHAR(5),
        unit_height  VARCHAR(4),
        weight       VARCHAR(4),
        unit_weight  VARCHAR(4),
        flag         VARCHAR(10),
        create_ts    DATETIME
    );

    -- 2. 清空表数据
    TRUNCATE TABLE user_info_sup_msg;

    -- 3. 插入新数据
    INSERT INTO user_info_sup_msg
    SELECT
        NULL,
        id AS uid,
        gender,
        height,
        unit_height,
        weight,
        unit_weight,
        flag,
        create_ts
    FROM (
        SELECT
            id,
            gender,
            CASE
                WHEN gender = 'M' THEN FLOOR(RAND() * 40) + 150  -- 男性身高 150-189
                WHEN gender = 'F' THEN FLOOR(RAND() * 35) + 140  -- 女性身高 140-174
                ELSE FLOOR(RAND() * 40) + 152                    -- 其他身高 152-191
            END AS height,
            'cm' AS unit_height,
            CASE
                WHEN gender = 'M' THEN FLOOR(RAND() * 45) + 50  -- 男性体重 50-94
                WHEN gender = 'F' THEN FLOOR(RAND() * 21) + 39  -- 女性体重 39-59
                ELSE FLOOR(RAND() * 47) + 39                    -- 其他体重 39-85
            END AS weight,
            'kg' AS unit_weight,
            CASE
                WHEN MOD(id, 7) = 0 THEN 'change'                -- ID能被7整除时标记为change
            END AS flag,
            CURRENT_TIMESTAMP AS create_ts
        FROM (
            SELECT
                id,
                gender
            FROM user_info
        ) AS t1
    ) AS t2;
END$$

DELIMITER ;



call task_sup_user_info();










create table if not exists category_compare_dic(
    id int auto_increment primary key ,
    category_name varchar(255),
    search_category varchar(255)
);

INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (1, '服饰内衣', '时尚与潮流');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (2, '新款', '时尚与潮流');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (3, '时尚', '时尚与潮流');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (4, '优惠', '性价比');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (5, '折扣', '性价比');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (6, '便宜', '性价比');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (7, '健康食品', '健康与养生');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (8, '保健品', '健康与养生');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (9, '养生', '健康与养生');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (10, '婴儿用品', '家庭与育儿');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (11, '儿童玩具', '家庭与育儿');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (12, '亲子活动', '家庭与育儿');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (13, '智能手机', '科技与数码');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (14, '电脑配件', '科技与数码');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (15, '智能设备', '科技与数码');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (16, '在线课程', '学习与发展');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (17, '书籍', '学习与发展');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (18, '技能提升', '学习与发展');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (19, '数码', '科技与数码');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (20, '汽车用品', '家庭与育儿');
INSERT INTO flink_realtime.category_compare_dic (id, category_name, search_category) VALUES (21, '家用电器', '家庭与育儿');